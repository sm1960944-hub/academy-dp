// حركة Fade عند النزول

const faders = document.querySelectorAll(".fade");

window.addEventListener("scroll", () => {

  faders.forEach(el => {

    const rect = el.getBoundingClientRect().top;

    if (rect < window.innerHeight - 100) {

      el.classList.add("show");

    }

  });

});

// رسالة التسجيل

document.getElementById("registerForm").addEventListener("submit", function(e){

  e.preventDefault();

  document.getElementById("successMsg").innerText = "تم التسجيل بنجاح ✅ سيتم التواصل معك قريبًا";

  this.reset();

});